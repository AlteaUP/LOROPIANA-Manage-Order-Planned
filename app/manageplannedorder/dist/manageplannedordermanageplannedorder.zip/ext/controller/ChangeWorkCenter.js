sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{doChangeWorkCenter:function(n){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=ChangeWorkCenter.js.map